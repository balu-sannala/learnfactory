package com.abc;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
@WebServlet("/kyc")
@MultipartConfig(maxFileSize = 16177215) 
public class Kyc extends HttpServlet{
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ResourceBundle bundle = ResourceBundle.getBundle("utilities.mysqlinfo");
		String url = bundle.getString("url");
		String user = bundle.getString("user");
		String password = bundle.getString("pwd");
		
		HttpSession session = req.getSession();
		String attribute = (String) session.getAttribute("id");
		System.out.println(attribute);
		InputStream inputStream = null; 

		Part filePart = req.getPart("idcard");
		if (filePart != null) {
			System.out.println(filePart.getName());
			System.out.println(filePart.getSize());
			System.out.println(filePart.getContentType());
			inputStream = filePart.getInputStream();
		}
		
		try {
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "update users set college_id = ?  where id = ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			 if (inputStream != null) {
	                // fetches input stream of the upload file for the blob column
	                stmt.setBlob(1, inputStream);
	            }
			 stmt.setString(2, attribute);
			int row = stmt.executeUpdate();
			System.out.println(row+" gets effected");
			resp.sendRedirect("details.html");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}
}
