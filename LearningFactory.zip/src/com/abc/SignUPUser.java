package com.abc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/signup")
public class SignUPUser extends HttpServlet{
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ResourceBundle bundle = ResourceBundle.getBundle("utilities.mysqlinfo");
		String url = bundle.getString("url");
		String user = bundle.getString("user");
		String password = bundle.getString("pwd");

		String uname = req.getParameter("mail");
		String pwd = req.getParameter("pwd");
		try {
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "Insert into users(uname,password) values(?,?)";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, uname);
			stmt.setString(2, pwd);
			int row = stmt.executeUpdate();
			System.out.println(row+" gets effected");
			resp.sendRedirect("login.html");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
