package com.abc;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
@WebServlet("/selfie")
@MultipartConfig(maxFileSize = 16177215) 
public class Selfie extends HttpServlet{
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ResourceBundle bundle = ResourceBundle.getBundle("utilities.mysqlinfo");
		String url = bundle.getString("url");
		String user = bundle.getString("user");
		String password = bundle.getString("pwd");

		HttpSession session = req.getSession();
		String attribute = (String) session.getAttribute("id");
		System.out.println(attribute);
		InputStream inputStream = null; 

		PrintWriter out = resp.getWriter();
		out.print("<!DOCTYPE html>\n" + 
				"<html>\n" + 
				"<head>\n" + 
				"	<title></title>\n" + 
				"	<style type=\"text/css\">\n" + 
				"		\n" + 
				"		h1{\n" + 
				"			font-size: 400%;\n" + 
				"			color: green\n" + 
				"		}\n" + 
				"	</style>\n" + 
				"</head>\n" + 
				"<body>\n" + 
				"	<center>\n" + 
				"		<h1>KYC DONE SUCCESSFULL</h1>\n" + 
				"	</center>\n" + 
				"\n" + 
				"</body>\n" + 
				"</html>");



	}
}
