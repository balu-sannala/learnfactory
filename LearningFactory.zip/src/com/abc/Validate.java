package com.abc;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/validate")
public class Validate  extends HttpServlet{
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ResourceBundle bundle = ResourceBundle.getBundle("utilities.mysqlinfo");
		String url = bundle.getString("url");
		String user = bundle.getString("user");
		String password = bundle.getString("pwd");

		String uname = req.getParameter("mail");
		String pwd = req.getParameter("pwd");
		try {
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "select  id,uname,password from users where uname=? and password=?";
			PreparedStatement statement = con.prepareStatement(sql);

			ResultSet resultSet = null;
			if(uname.length()>0 && pwd.length()>0) {
				statement.setString(1, uname);
				statement.setString(2, pwd);
				resultSet = statement.executeQuery();
				String id = null;
				String username = null;
				String userpwd = null;
				while(resultSet.next()) {
					id = resultSet.getString(1);
					username = resultSet.getString(2);
					userpwd = resultSet.getString(3);

				}


				System.out.println(id+" "+username+" "+userpwd);
				if(uname.equals(username) && userpwd.equals(userpwd)) {
					HttpSession session = req.getSession();
					session.setAttribute("id", id);
					resp.sendRedirect("kyc.html");
				}
				else {
					PrintWriter out = resp.getWriter();
					out.print("<!DOCTYPE html>\n" + 
							"<html>\n" + 
							"\n" + 
							"<head>\n" + 
							"    <meta charset=\"UTF-8\">\n" + 
							"    <title>Login Page</title>\n" + 
							"    <style>\n" + 
							"        .section-login {\n" + 
							"            width: 400px;\n" + 
							"            margin: 0 auto;\n" + 
							"        }\n" + 
							"        h1{\n" + 
							"            text-align: center;\n" + 
							"        }\n" + 
							"        input[type=\"text\"]{\n" + 
							"            width: 100%;\n" + 
							"            padding: 10px;\n" + 
							"           \n" + 
							"        }\n" + 
							"        .adjust{\n" + 
							"            margin-bottom:5px;\n" + 
							"        }\n" + 
							"        small{\n" + 
							"            color:red\n" + 
							"        }\n" + 
							"\n" + 
							"    </style>\n" + 
							"</head>\n" + 
							"\n" + 
							"<body>\n" + 
							"    <div class=\"section-login\">\n" + 
							"        <h1>Login</h1>\n" + 
							"        <form action=\"validate\">\n" + 
							"            <input type=\"text\" placeholder=\"Enter Mail ID\" name=\"mail\" class=\"adjust\"><br>\n" + 
							"            <input type=\"text\" placeholder=\"Enter Password\" name=\"pwd\" class=\"adjust\"><br>\n" + 
							"            <small>username or password not matched</small><br>\n" + 
							"            <input type=\"submit\">\n" + 
							"        </form>\n" + 
							"    </div>\n" + 
							"\n" + 
							"</body>\n" + 
							"\n" + 
							"</html>");

				}
			}
			else {
				PrintWriter out = resp.getWriter();
				out.print("<!DOCTYPE html>\n" + 
						"<html>\n" + 
						"\n" + 
						"<head>\n" + 
						"    <meta charset=\"UTF-8\">\n" + 
						"    <title>Login Page</title>\n" + 
						"    <style>\n" + 
						"        .section-login {\n" + 
						"            width: 400px;\n" + 
						"            margin: 0 auto;\n" + 
						"        }\n" + 
						"        h1{\n" + 
						"            text-align: center;\n" + 
						"        }\n" + 
						"        input[type=\"text\"]{\n" + 
						"            width: 100%;\n" + 
						"            padding: 10px;\n" + 
						"           \n" + 
						"        }\n" + 
						"        .adjust{\n" + 
						"            margin-bottom:5px;\n" + 
						"        }\n" + 
						"        small{\n" + 
						"            color:red\n" + 
						"        }\n" + 
						"\n" + 
						"    </style>\n" + 
						"</head>\n" + 
						"\n" + 
						"<body>\n" + 
						"    <div class=\"section-login\">\n" + 
						"        <h1>Login</h1>\n" + 
						"        <form action=\"validate\">\n" + 
						"            <input type=\"text\" placeholder=\"Enter Mail ID\" name=\"mail\" class=\"adjust\"><br>\n" + 
						"            <input type=\"text\" placeholder=\"Enter Password\" name=\"pwd\" class=\"adjust\"><br>\n" + 
						"            <small>username or password not matched</small><br>\n" + 
						"            <input type=\"submit\">\n" + 
						"        </form>\n" + 
						"    </div>\n" + 
						"\n" + 
						"</body>\n" + 
						"\n" + 
						"</html>");

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
