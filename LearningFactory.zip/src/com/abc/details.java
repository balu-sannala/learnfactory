package com.abc;
import java.io.IOException;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/details")
public class details extends HttpServlet {
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		ResourceBundle bundle = ResourceBundle.getBundle("utilities.mysqlinfo");
		String url = bundle.getString("url");
		String user = bundle.getString("user");
		String password = bundle.getString("pwd");

		HttpSession session = req.getSession();
		String attribute = (String) session.getAttribute("id");
		System.out.println("detials"+attribute);

		String fullname = req.getParameter("fullname");
		String gender = req.getParameter("gender");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String date = req.getParameter("date");
		String experience = req.getParameter("experience");
		
		try {
			Connection con = DriverManager.getConnection(url, user, password);
			String sql = "update users set full_name = ? ,gender = ? , dob = ? ,experience = ? where id = ?";
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, fullname);
			stmt.setString(2, gender);
			stmt.setString(3, date);
			stmt.setString(4, experience);
			stmt.setString(5, attribute);
			int row = stmt.executeUpdate();
			System.out.println(row+" gets effected");
			resp.sendRedirect("selfie.html");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
